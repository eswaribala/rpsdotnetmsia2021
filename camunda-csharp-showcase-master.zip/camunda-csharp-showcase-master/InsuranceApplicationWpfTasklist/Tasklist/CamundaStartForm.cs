﻿using CamundaClient.Dto;

namespace InsuranceApplicationWpfTasklist
{
    internal interface CamundaStartForm
    {
        void initialize(TasklistWindow taskist, ProcessDefinition processDefinition);
    }
}