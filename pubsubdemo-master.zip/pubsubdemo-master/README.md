# pubsubdemo
A pub/sub scenario with MassTransit, RabbitMQ and .NET Core

Documentation:

https://medium.com/@alikzlda/a-simple-pub-sub-scenario-with-masstransit-6-2-rabbitmq-net-core-3-1-elasticsearch-mssql-5a65c993b2fd
