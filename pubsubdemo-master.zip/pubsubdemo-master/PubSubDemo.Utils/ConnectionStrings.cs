﻿using System;

namespace PubSubDemo.Utils
{
    public class ConnectionStrings
    {
        public string Main { get; set; }

    }
}
