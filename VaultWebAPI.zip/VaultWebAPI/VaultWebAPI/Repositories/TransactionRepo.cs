﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VaultWebAPI.Contexts;
using VaultWebAPI.Models;

namespace VaultWebAPI.Repositories
{
    public class TransactionRepo : ITransactionRepo
    {
        private readonly TransactionContext _dbContext;

        //dependency injection
        public TransactionRepo(TransactionContext dbContext)
        {
            this._dbContext = dbContext;

        }

        public Transaction AddTransaction(Transaction transaction)
        {
            this._dbContext.Add(transaction);
            Save();
            return transaction;
        }

        public void DeleteTransaction(long transactionId)
        {
            var transaction = _dbContext.Transactions.Find(transactionId);
            _dbContext.Transactions.Remove(transaction);
            Save();
        }

        public IEnumerable<Transaction> GetAllTransactions()
        {
            return _dbContext.Transactions.ToList();

        }

        public Transaction UpdateTransaction(Transaction transaction)
        {
            _dbContext.Entry(transaction).State = EntityState.Modified;
            Save();
            return transaction;
        }
        public void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
