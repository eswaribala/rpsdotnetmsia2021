﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VaultWebAPI.Models;

namespace VaultWebAPI.Repositories
{
   public interface ITransactionRepo
    {
        Transaction AddTransaction(Transaction transaction);
        IEnumerable<Transaction> GetAllTransactions();
        Transaction UpdateTransaction(Transaction transaction);

        void DeleteTransaction(long transactionId);
    }
}
